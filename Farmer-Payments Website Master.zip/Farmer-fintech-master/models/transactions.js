var mongoose = require("mongoose");


var TransSchema=new mongoose.Schema({
     name    : String,
	 reason  : String,
	 amount  : Number,
	 date    : String
	
});
module.exports=mongoose.model("Trans",TransSchema);